
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
				quantum: {
					50: '#f0f7ff',
					100: '#e0efff', 
					200: '#bae0ff',
					300: '#7cc6ff',
					400: '#38a5fc',
					500: '#0f87ee',
					600: '#006bcd',
					700: '#0054a7',
					800: '#054989',
					900: '#0a3e72',
					950: '#072649',
				},
				emerald: {
					50: '#edfff9',
					100: '#d6fff2',
					200: '#affee5',
					300: '#73fdd3',
					400: '#33f3b8',
					500: '#0de09e',
					600: '#00c080',
					700: '#009868',
					800: '#067655',
					900: '#076148',
					950: '#003829',
				},
				purple: {
					50: '#faf5ff',
					100: '#f4e8ff',
					200: '#ebd5ff',
					300: '#dab6fe',
					400: '#c387fd',
					500: '#ab57fb',
					600: '#9935f0',
					700: '#8522d0',
					800: '#701dab',
					900: '#5d1a8a',
					950: '#3b0764',
				},
				sidebar: {
					DEFAULT: 'hsl(var(--sidebar-background))',
					foreground: 'hsl(var(--sidebar-foreground))',
					primary: 'hsl(var(--sidebar-primary))',
					'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
					accent: 'hsl(var(--sidebar-accent))',
					'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
					border: 'hsl(var(--sidebar-border))',
					ring: 'hsl(var(--sidebar-ring))'
				}
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				'float': {
					'0%, 100%': {
						transform: 'translateY(0)'
					},
					'50%': {
						transform: 'translateY(-10px)'
					}
				},
				'glow': {
					'0%, 100%': {
						opacity: '0.6'
					},
					'50%': {
						opacity: '1'
					}
				},
				'gradient-flow': {
					'0%': { backgroundPosition: '0% 50%' },
					'50%': { backgroundPosition: '100% 50%' },
					'100%': { backgroundPosition: '0% 50%' }
				},
				'pulse-soft': {
					'0%, 100%': {
						transform: 'scale(1)',
						opacity: '0.9'
					},
					'50%': {
						transform: 'scale(1.05)',
						opacity: '1'
					}
				}
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'float': 'float 6s ease-in-out infinite',
				'glow': 'glow 3s ease-in-out infinite',
				'gradient-flow': 'gradient-flow 8s ease infinite',
				'pulse-soft': 'pulse-soft 6s ease-in-out infinite'
			},
			boxShadow: {
				'quantum': '0 0 25px -5px rgba(171, 87, 251, 0.2), 0 0 10px -5px rgba(171, 87, 251, 0.2)'
			},
			backgroundImage: {
				'gradient-quantum': 'linear-gradient(135deg, rgba(171, 87, 251, 0.5), rgba(13, 224, 158, 0.5))',
				'gradient-dark': 'linear-gradient(135deg, rgba(7, 38, 73, 0.9), rgba(59, 7, 100, 0.9))'
			}
		}
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
