
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CirclePlus, Code, History, Settings } from "lucide-react";

const Dashboard = () => {
  const [isDarkTheme, setIsDarkTheme] = useState(false);
  
  // Sample code that would be displayed in the editor
  const sampleCode = `# Bell State Preparation
from qiskit import QuantumCircuit, Aer, execute
from qiskit.visualization import plot_histogram

# Create a Quantum Circuit with 2 qubits & 2 classical bits
qc = QuantumCircuit(2, 2)

# Apply H-gate to the first qubit
qc.h(0)

# Apply CNOT with control qubit 0 and target qubit 1
qc.cx(0, 1)

# Measure the qubits
qc.measure([0,1], [0,1])

# Use the Aer simulator
simulator = Aer.get_backend('qasm_simulator')

# Execute the circuit
job = execute(qc, simulator, shots=1000)
result = job.result()

# Get the counts
counts = result.get_counts(qc)
print(counts)

# Plot the results
plot_histogram(counts)`;

  // Demo projects
  const projects = [
    { name: "Bell State Demo", lastModified: "Today", status: "Ready" },
    { name: "Quantum Teleportation", lastModified: "Yesterday", status: "Running" },
    { name: "Shor's Algorithm Test", lastModified: "3 days ago", status: "Failed" },
    { name: "Grover's Search Example", lastModified: "1 week ago", status: "Completed" }
  ];
  
  return (
    <div className="flex min-h-screen bg-muted/30">
      {/* Sidebar */}
      <div className="hidden md:flex w-64 border-r border-border bg-card flex-col">
        <div className="p-4 border-b border-border">
          <h2 className="text-2xl font-bold gradient-text">Sonicium Q</h2>
        </div>
        
        <div className="p-4">
          <nav className="space-y-1">
            <a 
              href="#" 
              className="flex items-center px-3 py-2 rounded-md bg-primary/10 text-primary"
            >
              <Code className="mr-2 h-5 w-5" />
              Projects
            </a>
            <a 
              href="#" 
              className="flex items-center px-3 py-2 rounded-md hover:bg-muted"
            >
              <History className="mr-2 h-5 w-5" />
              Job History
            </a>
            <a 
              href="#" 
              className="flex items-center px-3 py-2 rounded-md hover:bg-muted"
            >
              <Settings className="mr-2 h-5 w-5" />
              Settings
            </a>
          </nav>
        </div>
        
        <div className="mt-auto p-4 border-t border-border">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
              U
            </div>
            <div className="ml-3">
              <p className="font-medium">User Name</p>
              <p className="text-xs text-foreground/70">Premium Plan</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-1 p-6 lg:p-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome to your Quantum Dashboard</h1>
          <p className="text-foreground/70">
            Build, manage, and execute your quantum computing projects
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Projects</CardTitle>
              <CardDescription>Your quantum code repositories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{projects.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Queue Status</CardTitle>
              <CardDescription>Job processing priority</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-emerald-500">Ready</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Credits</CardTitle>
              <CardDescription>Available computing credits</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">5,000</div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="projects" className="mb-8">
          <TabsList>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="editor">Code Editor</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
          </TabsList>
          
          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-4 py-4">
            <div className="flex justify-between mb-4">
              <h2 className="text-2xl font-semibold">Your Projects</h2>
              <Button>
                <CirclePlus className="mr-2 h-4 w-4" />
                New Project
              </Button>
            </div>
            
            <div className="border rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-foreground/70 uppercase tracking-wider">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-foreground/70 uppercase tracking-wider">
                      Last Modified
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-foreground/70 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-foreground/70 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-card divide-y divide-border">
                  {projects.map((project, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium">{project.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-foreground/70">
                        {project.lastModified}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                          ${project.status === 'Ready' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300' : 
                            project.status === 'Running' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300' : 
                              project.status === 'Failed' ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300' : 
                                'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'}`}
                        >
                          {project.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <Button variant="ghost" size="sm">Open</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
          
          {/* Code Editor Tab */}
          <TabsContent value="editor" className="space-y-4 py-4">
            <div className="flex justify-between mb-4">
              <h2 className="text-2xl font-semibold">Quantum Code Editor</h2>
              <Button>Run</Button>
            </div>
            
            <div className="border rounded-lg overflow-hidden bg-card">
              <div className="bg-muted px-4 py-2 border-b border-border flex justify-between">
                <div className="text-sm font-medium">bell_state.py</div>
                <div className="text-xs text-foreground/60">Python / Qiskit</div>
              </div>
              <pre className="p-4 text-sm font-mono overflow-auto h-96">{sampleCode}</pre>
            </div>
          </TabsContent>
          
          {/* Results Tab */}
          <TabsContent value="results" className="py-4">
            <div className="flex justify-between mb-4">
              <h2 className="text-2xl font-semibold">Execution Results</h2>
              <Button variant="outline">Export</Button>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Bell State Results</CardTitle>
                <CardDescription>Executed on IBM Quantum Simulator</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-40 bg-muted rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-foreground/70 mb-2">Result Visualization</p>
                    <p className="font-mono">{'{'}'00': 489, '11': 511{'}'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Dashboard;
