
import { useState, useEffect } from "react";
import NavBar from "@/components/layout/NavBar";
import Footer from "@/components/layout/Footer";
import HeroSection from "@/components/home/HeroSection";
import FeaturesSection from "@/components/home/FeaturesSection";
import PricingSection from "@/components/home/PricingSection";
import BioSection from "@/components/home/BioSection";
import TechStackSection from "@/components/home/TechStackSection";
import CodeSnippetSection from "@/components/home/CodeSnippetSection";

const Index = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // Check system preference on initial load
  useEffect(() => {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setIsDarkMode(prefersDark);
    
    if (prefersDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);
  
  // Toggle between light and dark mode
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    
    if (!isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <NavBar isDarkMode={isDarkMode} toggleDarkMode={toggleDarkMode} />
      
      <main className="flex-grow">
        <HeroSection />
        <FeaturesSection />
        <CodeSnippetSection />
        <PricingSection />
        <BioSection />
        <TechStackSection />
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
