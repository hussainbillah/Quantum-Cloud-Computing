
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/use-toast";
import { CreditCard, Info } from "lucide-react";

const AdminPaymentGateway = () => {
  const [sslCommerzSettings, setSslCommerzSettings] = useState({
    storeId: "",
    storePassword: "",
    testMode: true,
    enabled: false
  });

  const handleSaveSettings = () => {
    toast({
      title: "Settings saved",
      description: "Your payment gateway settings have been saved successfully.",
    });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Payment Gateway Settings</h1>
      
      <Tabs defaultValue="sslcommerz">
        <TabsList className="mb-4">
          <TabsTrigger value="sslcommerz">SSLCommerz</TabsTrigger>
          <TabsTrigger value="other" disabled>Other Gateways</TabsTrigger>
        </TabsList>
        
        <TabsContent value="sslcommerz" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="mr-2 h-4 w-4" />
                SSLCommerz Configuration
              </CardTitle>
              <CardDescription>
                Set up SSLCommerz payment gateway for processing payments
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="gateway-status">Gateway Status</Label>
                  <p className="text-sm text-muted-foreground">
                    Enable or disable SSLCommerz payments
                  </p>
                </div>
                <Switch
                  id="gateway-status"
                  checked={sslCommerzSettings.enabled}
                  onCheckedChange={(checked) => 
                    setSslCommerzSettings({...sslCommerzSettings, enabled: checked})
                  }
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="test-mode">Test Mode</Label>
                  <p className="text-sm text-muted-foreground">
                    Run in sandbox environment
                  </p>
                </div>
                <Switch
                  id="test-mode"
                  checked={sslCommerzSettings.testMode}
                  onCheckedChange={(checked) => 
                    setSslCommerzSettings({...sslCommerzSettings, testMode: checked})
                  }
                />
              </div>
              
              <div className="space-y-2 pt-2">
                <Label htmlFor="store-id">Store ID</Label>
                <Input
                  id="store-id"
                  placeholder="Your SSLCommerz Store ID"
                  value={sslCommerzSettings.storeId}
                  onChange={(e) => 
                    setSslCommerzSettings({...sslCommerzSettings, storeId: e.target.value})
                  }
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="store-password">Store Password</Label>
                <Input
                  id="store-password"
                  type="password"
                  placeholder="Your SSLCommerz Store Password"
                  value={sslCommerzSettings.storePassword}
                  onChange={(e) => 
                    setSslCommerzSettings({...sslCommerzSettings, storePassword: e.target.value})
                  }
                />
              </div>
              
              <div className="rounded-md bg-muted p-4">
                <div className="flex">
                  <Info className="h-5 w-5 text-primary mr-2" />
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Integration Information</p>
                    <p className="text-sm">
                      Make sure to set up the correct IPN and success/fail URLs in your SSLCommerz dashboard.
                      Webhook URL: <code className="text-xs bg-muted-foreground/20 p-1 rounded">https://yourdomain.com/api/webhooks/sslcommerz</code>
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveSettings}>Save Gateway Settings</Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Test Integration</CardTitle>
              <CardDescription>
                Generate a test transaction to ensure the integration is working correctly
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                This will create a test payment flow without actually charging any payment method.
              </p>
              <Button variant="outline">Run Test Transaction</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminPaymentGateway;
