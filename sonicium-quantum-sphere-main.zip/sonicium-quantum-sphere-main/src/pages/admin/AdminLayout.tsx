
import { Outlet, useNavigate, Link } from "react-router-dom";
import { 
  SidebarProvider, 
  Sidebar, 
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarTrigger,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent
} from "@/components/ui/sidebar";
import { AdminProtectedRoute } from "@/components/admin/AdminProtectedRoute";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  Users, 
  CreditCard, 
  Store, 
  Ticket, 
  Activity, 
  Settings, 
  LogOut,
  BadgeHelp
} from "lucide-react";
import { useAdminAuth } from "@/contexts/AdminAuthContext";

const AdminLayout = () => {
  const { adminLogout, currentAdmin } = useAdminAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await adminLogout();
    navigate("/admin/login");
  };

  return (
    <AdminProtectedRoute>
      <SidebarProvider>
        <div className="flex min-h-screen w-full bg-muted/10">
          <Sidebar>
            <SidebarHeader>
              <div className="flex items-center gap-2 px-4 pt-2">
                <span className="text-xl font-bold">Sonicium Q</span>
              </div>
              <div className="px-4 py-2">
                <span className="text-sm text-muted-foreground">Admin Dashboard</span>
              </div>
            </SidebarHeader>
            
            <SidebarContent>
              <SidebarGroup>
                <SidebarGroupLabel>Main</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <Link to="/admin">
                          <LayoutDashboard />
                          <span>Dashboard</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <Link to="/admin/users">
                          <Users />
                          <span>Users</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
              
              <SidebarGroup>
                <SidebarGroupLabel>Payments</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <Link to="/admin/payments">
                          <CreditCard />
                          <span>Payments</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <Link to="/admin/payment-gateway">
                          <Store />
                          <span>Payment Gateway</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <Link to="/admin/subscriptions">
                          <Ticket />
                          <span>Subscriptions</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
              
              <SidebarGroup>
                <SidebarGroupLabel>System</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <Link to="/admin/quantum-logs">
                          <Activity />
                          <span>Quantum Logs</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <Link to="/admin/settings">
                          <Settings />
                          <span>Settings</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>
            
            <SidebarFooter>
              {currentAdmin && (
                <div className="px-4 py-2 mb-2">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium">{currentAdmin.email}</p>
                    <p className="text-xs text-muted-foreground capitalize">{currentAdmin.role || 'Admin'}</p>
                  </div>
                </div>
              )}
              <div className="px-4 pb-4">
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Log out
                </Button>
              </div>
            </SidebarFooter>
          </Sidebar>
          
          <div className="flex flex-1 flex-col">
            <header className="sticky top-0 z-10 flex h-16 items-center border-b bg-background px-4 md:px-6">
              <div className="flex items-center gap-4">
                <SidebarTrigger />
                <h1 className="text-xl font-semibold">Admin Dashboard</h1>
              </div>
              <div className="ml-auto flex items-center gap-4">
                <Button variant="ghost" size="icon">
                  <BadgeHelp className="h-5 w-5" />
                </Button>
              </div>
            </header>
            
            <main className="flex-1 p-4 md:p-6">
              <Outlet />
            </main>
          </div>
        </div>
      </SidebarProvider>
    </AdminProtectedRoute>
  );
};

export default AdminLayout;
