
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/components/ui/use-toast";
import { Search, Eye, Download, Loader2, Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";

type QuantumLog = {
  id: string;
  user_id: string;
  user_email?: string;
  project_name: string;
  operation_type: string;
  execution_time: number;
  status: string;
  details: Record<string, any>;
  created_at: string;
};

const AdminQuantumLogs = () => {
  const [logs, setLogs] = useState<QuantumLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<QuantumLog[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchQuantumLogs();
  }, []);

  useEffect(() => {
    if (searchTerm) {
      const filtered = logs.filter(
        log => 
          log.user_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          log.project_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          log.operation_type.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredLogs(filtered);
    } else {
      setFilteredLogs(logs);
    }
  }, [searchTerm, logs]);

  async function fetchQuantumLogs() {
    try {
      setLoading(true);
      
      // Get quantum logs
      const { data, error } = await supabase
        .from('quantum_logs')
        .select(`
          *,
          user_id
        `)
        .order('created_at', { ascending: false })
        .limit(100);
      
      if (error) throw error;
      
      // Fetch user emails in a second step
      const logsWithEmails = await Promise.all(
        (data || []).map(async (log) => {
          // Get user email from auth
          const { data: userData } = await supabase.auth.admin.getUserById(
            log.user_id
          );
          
          return {
            ...log,
            user_email: userData?.user?.email || 'Unknown'
          };
        })
      );
      
      setLogs(logsWithEmails);
      setFilteredLogs(logsWithEmails);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to fetch quantum logs",
      });
    } finally {
      setLoading(false);
    }
  }

  const getStatusBadgeVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case 'success':
      case 'completed':
        return "default";
      case 'processing':
      case 'pending':
        return "outline";
      case 'failed':
      case 'error':
        return "destructive";
      default:
        return "secondary";
    }
  };

  const formatExecutionTime = (time: number) => {
    if (!time) return 'N/A';
    return time < 1000 ? `${time}ms` : `${(time / 1000).toFixed(2)}s`;
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Quantum Logs</h1>
        <div className="space-x-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Operation Logs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-4">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search logs..."
                className="w-full pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Project</TableHead>
                  <TableHead>Operation</TableHead>
                  <TableHead>Execution Time</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">
                      <div className="flex justify-center items-center">
                        <Loader2 className="h-6 w-6 animate-spin mr-2" />
                        Loading logs...
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredLogs.length > 0 ? (
                  filteredLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="whitespace-nowrap">
                        {new Date(log.created_at).toLocaleString()}
                      </TableCell>
                      <TableCell>{log.user_email}</TableCell>
                      <TableCell>{log.project_name}</TableCell>
                      <TableCell className="capitalize">{log.operation_type}</TableCell>
                      <TableCell>{formatExecutionTime(log.execution_time)}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(log.status)} className="capitalize">
                          {log.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">
                      No logs found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminQuantumLogs;
