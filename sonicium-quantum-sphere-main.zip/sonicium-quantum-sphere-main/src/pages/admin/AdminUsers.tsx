
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/components/ui/use-toast";
import { 
  Search, 
  Edit, 
  Trash2, 
  MoreHorizontal, 
  Loader2,
  UserPlus
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

type User = {
  id: string;
  email: string;
  created_at: string;
  last_sign_in_at: string | null;
  stats?: {
    login_count: number;
    quantum_projects_count: number;
  };
  subscription?: {
    name: string;
    status: string;
  };
};

const AdminUsers = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [editForm, setEditForm] = useState({
    email: "",
    subscription: ""
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  useEffect(() => {
    if (searchTerm) {
      const filtered = users.filter(
        user => user.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [searchTerm, users]);

  async function fetchUsers() {
    try {
      setLoading(true);
      
      // Get all users from auth.users (this requires admin rights)
      const { data: authUsers, error: authError } = await supabase.auth.admin.listUsers();
      
      if (authError) {
        toast({
          variant: "destructive",
          title: "Error fetching users",
          description: authError.message,
        });
        return;
      }
      
      // For each user, get their stats and subscription
      const usersWithDetails = await Promise.all(
        authUsers.users.map(async (user) => {
          // Fetch user stats
          const { data: stats } = await supabase
            .from('user_stats')
            .select('login_count, quantum_projects_count')
            .eq('user_id', user.id)
            .single();
            
          // Fetch user subscription
          const { data: subscription } = await supabase
            .from('user_subscriptions')
            .select('status, subscription_plans(name)')
            .eq('user_id', user.id)
            .eq('status', 'active')
            .single();
            
          return {
            id: user.id,
            email: user.email,
            created_at: user.created_at,
            last_sign_in_at: user.last_sign_in_at,
            stats,
            subscription: subscription 
              ? { name: subscription.subscription_plans.name, status: subscription.status } 
              : undefined
          };
        })
      );
      
      setUsers(usersWithDetails);
      setFilteredUsers(usersWithDetails);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to fetch users",
      });
    } finally {
      setLoading(false);
    }
  }

  const handleEditUser = (user: User) => {
    setCurrentUser(user);
    setEditForm({
      email: user.email,
      subscription: user.subscription?.name || ""
    });
    setIsEditDialogOpen(true);
  };

  const handleDeleteUser = (user: User) => {
    setCurrentUser(user);
    setIsDeleteDialogOpen(true);
  };

  const confirmEditUser = async () => {
    if (!currentUser) return;
    
    try {
      // Update user email in auth
      const { error: updateError } = await supabase.auth.admin.updateUserById(
        currentUser.id,
        { email: editForm.email }
      );
      
      if (updateError) throw updateError;
      
      toast({
        title: "User updated",
        description: "User information has been updated successfully",
      });
      
      // Refresh the users list
      fetchUsers();
      setIsEditDialogOpen(false);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: error.message || "Failed to update user",
      });
    }
  };

  const confirmDeleteUser = async () => {
    if (!currentUser) return;
    
    try {
      // Delete user from auth
      const { error: deleteError } = await supabase.auth.admin.deleteUser(
        currentUser.id
      );
      
      if (deleteError) throw deleteError;
      
      toast({
        title: "User deleted",
        description: "User has been deleted successfully",
      });
      
      // Refresh the users list
      fetchUsers();
      setIsDeleteDialogOpen(false);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Deletion failed",
        description: error.message || "Failed to delete user",
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">User Management</h1>
        <Button>
          <UserPlus className="mr-2 h-4 w-4" />
          Add User
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-4">
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search by email..."
                className="w-full pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Created At</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead>Login Count</TableHead>
                  <TableHead>Projects</TableHead>
                  <TableHead>Subscription</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">
                      <div className="flex justify-center items-center">
                        <Loader2 className="h-6 w-6 animate-spin mr-2" />
                        Loading users...
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredUsers.length > 0 ? (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{new Date(user.created_at).toLocaleDateString()}</TableCell>
                      <TableCell>
                        {user.last_sign_in_at 
                          ? new Date(user.last_sign_in_at).toLocaleDateString() 
                          : 'Never'}
                      </TableCell>
                      <TableCell>{user.stats?.login_count || 0}</TableCell>
                      <TableCell>{user.stats?.quantum_projects_count || 0}</TableCell>
                      <TableCell>
                        {user.subscription ? (
                          <Badge variant="outline" className="capitalize">
                            {user.subscription.name}
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-muted">
                            None
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleEditUser(user)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleDeleteUser(user)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8">
                      No users found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      
      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>
              Update user information. Changes will be applied immediately.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                value={editForm.email}
                onChange={(e) => setEditForm({...editForm, email: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="subscription">Subscription</Label>
              <Input
                id="subscription"
                value={editForm.subscription}
                onChange={(e) => setEditForm({...editForm, subscription: e.target.value})}
                disabled
              />
              <p className="text-xs text-muted-foreground">
                Subscription can be changed in the Subscriptions section
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={confirmEditUser}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete User Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete User</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this user? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmDeleteUser}>
              Delete User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminUsers;
