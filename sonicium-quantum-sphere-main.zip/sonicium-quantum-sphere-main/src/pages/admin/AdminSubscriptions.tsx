
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/components/ui/use-toast";
import { Edit, Plus, Trash2, Loader2 } from "lucide-react";

type SubscriptionPlan = {
  id: string;
  name: string;
  price: number;
  features: Record<string, any>;
  duration_days: number;
  created_at: string;
  updated_at: string;
};

const AdminSubscriptions = () => {
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [currentPlan, setCurrentPlan] = useState<SubscriptionPlan | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    features: "",
    duration_days: ""
  });

  useEffect(() => {
    fetchSubscriptionPlans();
  }, []);

  async function fetchSubscriptionPlans() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('subscription_plans')
        .select('*')
        .order('price', { ascending: true });
      
      if (error) throw error;
      
      setPlans(data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to fetch subscription plans",
      });
    } finally {
      setLoading(false);
    }
  }

  const handleAddPlan = () => {
    setFormData({
      name: "",
      price: "",
      features: "",
      duration_days: "30"
    });
    setIsAddDialogOpen(true);
  };

  const handleEditPlan = (plan: SubscriptionPlan) => {
    setCurrentPlan(plan);
    setFormData({
      name: plan.name,
      price: plan.price.toString(),
      features: JSON.stringify(plan.features, null, 2),
      duration_days: plan.duration_days.toString()
    });
    setIsEditDialogOpen(true);
  };

  const handleDeletePlan = (plan: SubscriptionPlan) => {
    setCurrentPlan(plan);
    setIsDeleteDialogOpen(true);
  };

  const confirmAddPlan = async () => {
    try {
      let featuresObj = {};
      try {
        featuresObj = JSON.parse(formData.features);
      } catch (e) {
        toast({
          variant: "destructive",
          title: "Invalid JSON",
          description: "Features must be a valid JSON object",
        });
        return;
      }
      
      const { error } = await supabase
        .from('subscription_plans')
        .insert({
          name: formData.name,
          price: parseFloat(formData.price),
          features: featuresObj,
          duration_days: parseInt(formData.duration_days)
        });
      
      if (error) throw error;
      
      toast({
        title: "Plan created",
        description: "The subscription plan has been created successfully",
      });
      
      fetchSubscriptionPlans();
      setIsAddDialogOpen(false);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create subscription plan",
      });
    }
  };

  const confirmEditPlan = async () => {
    if (!currentPlan) return;
    
    try {
      let featuresObj = {};
      try {
        featuresObj = JSON.parse(formData.features);
      } catch (e) {
        toast({
          variant: "destructive",
          title: "Invalid JSON",
          description: "Features must be a valid JSON object",
        });
        return;
      }
      
      const { error } = await supabase
        .from('subscription_plans')
        .update({
          name: formData.name,
          price: parseFloat(formData.price),
          features: featuresObj,
          duration_days: parseInt(formData.duration_days),
          updated_at: new Date().toISOString()
        })
        .eq('id', currentPlan.id);
      
      if (error) throw error;
      
      toast({
        title: "Plan updated",
        description: "The subscription plan has been updated successfully",
      });
      
      fetchSubscriptionPlans();
      setIsEditDialogOpen(false);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to update subscription plan",
      });
    }
  };

  const confirmDeletePlan = async () => {
    if (!currentPlan) return;
    
    try {
      // Check if plan is in use
      const { count, error: countError } = await supabase
        .from('user_subscriptions')
        .select('*', { count: 'exact', head: true })
        .eq('plan_id', currentPlan.id);
      
      if (countError) throw countError;
      
      if (count && count > 0) {
        toast({
          variant: "destructive",
          title: "Cannot delete plan",
          description: "This plan is currently being used by one or more users",
        });
        setIsDeleteDialogOpen(false);
        return;
      }
      
      const { error } = await supabase
        .from('subscription_plans')
        .delete()
        .eq('id', currentPlan.id);
      
      if (error) throw error;
      
      toast({
        title: "Plan deleted",
        description: "The subscription plan has been deleted successfully",
      });
      
      fetchSubscriptionPlans();
      setIsDeleteDialogOpen(false);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to delete subscription plan",
      });
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'BDT'
    }).format(price);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Subscription Plans</h1>
        <Button onClick={handleAddPlan}>
          <Plus className="mr-2 h-4 w-4" />
          Add Plan
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Available Plans</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Features</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">
                      <div className="flex justify-center items-center">
                        <Loader2 className="h-6 w-6 animate-spin mr-2" />
                        Loading plans...
                      </div>
                    </TableCell>
                  </TableRow>
                ) : plans.length > 0 ? (
                  plans.map((plan) => (
                    <TableRow key={plan.id}>
                      <TableCell className="font-medium">{plan.name}</TableCell>
                      <TableCell>{formatPrice(plan.price)}</TableCell>
                      <TableCell>{plan.duration_days} days</TableCell>
                      <TableCell>
                        <div className="max-w-xs truncate">
                          {Object.entries(plan.features || {}).map(([key, value]) => (
                            <div key={key} className="text-xs">
                              <span className="font-medium">{key}:</span> {value?.toString()}
                            </div>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleEditPlan(plan)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleDeletePlan(plan)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">
                      No subscription plans found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      
      {/* Add Plan Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add Subscription Plan</DialogTitle>
            <DialogDescription>
              Create a new subscription plan for your users.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Plan Name</Label>
              <Input
                id="name"
                placeholder="e.g. Basic, Premium, Enterprise"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price">Price (BDT)</Label>
              <Input
                id="price"
                type="number"
                placeholder="499"
                value={formData.price}
                onChange={(e) => setFormData({...formData, price: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (Days)</Label>
              <Input
                id="duration"
                type="number"
                placeholder="30"
                value={formData.duration_days}
                onChange={(e) => setFormData({...formData, duration_days: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="features">
                Features (JSON)
                <span className="ml-1 text-xs text-muted-foreground">
                  e.g. {`{"quantum_projects": 5, "support": "email"}`}
                </span>
              </Label>
              <Textarea
                id="features"
                placeholder='{"quantum_projects": 5, "support": "email", "storage": "5GB"}'
                rows={5}
                value={formData.features}
                onChange={(e) => setFormData({...formData, features: e.target.value})}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={confirmAddPlan}>Add Plan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Plan Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Subscription Plan</DialogTitle>
            <DialogDescription>
              Update the subscription plan details.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Plan Name</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-price">Price (BDT)</Label>
              <Input
                id="edit-price"
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({...formData, price: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-duration">Duration (Days)</Label>
              <Input
                id="edit-duration"
                type="number"
                value={formData.duration_days}
                onChange={(e) => setFormData({...formData, duration_days: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-features">Features (JSON)</Label>
              <Textarea
                id="edit-features"
                rows={5}
                value={formData.features}
                onChange={(e) => setFormData({...formData, features: e.target.value})}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={confirmEditPlan}>Update Plan</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Plan Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Plan</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this plan? This action cannot be undone.
              Note: Plans that are currently in use cannot be deleted.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmDeletePlan}>
              Delete Plan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminSubscriptions;
