
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";
import { useAdminAuth } from "@/contexts/AdminAuthContext";

export function AdminNavLink() {
  const { isAdminAuthenticated } = useAdminAuth();

  // Only show admin link if user is authenticated as an admin
  if (!isAdminAuthenticated) return null;

  return (
    <Button asChild variant="ghost">
      <Link to="/admin" className="flex items-center">
        <Shield className="mr-1 h-4 w-4" />
        Admin
      </Link>
    </Button>
  );
}
