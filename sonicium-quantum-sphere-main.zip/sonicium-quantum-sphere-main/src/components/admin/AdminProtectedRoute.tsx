
import { useEffect } from "react";
import { useNavigate, Outlet } from "react-router-dom";
import { useAdminAuth } from "@/contexts/AdminAuthContext";
import { Loader2 } from "lucide-react";

interface AdminProtectedRouteProps {
  children?: React.ReactNode;
}

export function AdminProtectedRoute({ children }: AdminProtectedRouteProps) {
  const { isAdminAuthenticated, adminLoading } = useAdminAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!adminLoading && !isAdminAuthenticated) {
      navigate("/admin/login", { replace: true });
    }
  }, [isAdminAuthenticated, adminLoading, navigate]);

  if (adminLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2 text-lg">Loading admin panel...</span>
      </div>
    );
  }

  return children ? <>{children}</> : <Outlet />;
}
