
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const HeroSection = () => {
  return (
    <section className="relative pt-24 pb-20 md:pt-36 md:pb-32">
      {/* Background decorative elements */}
      <div className="absolute top-20 right-0 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl -z-10"></div>
      
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight">
            Run Real <span className="gradient-text">Sonicium Quantum Codes</span> via Sonicium Q
          </h1>
          <p className="text-lg md:text-xl text-foreground/80 mb-8 max-w-3xl mx-auto">
            Access the power of quantum computing through our secure, enterprise-grade platform. 
            Build, deploy, and execute quantum algorithms with unparalleled speed and precision.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
            <Button asChild size="lg" className="text-base">
              <Link to="/signup">Get Started</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="text-base">
              <Link to="/#pricing">View Pricing</Link>
            </Button>
          </div>
          
          {/* Abstract Quantum Circuit Visualization */}
          <div className="relative mx-auto w-full max-w-3xl h-64 sm:h-80 bg-gradient-to-br from-purple-950/30 to-emerald-900/30 rounded-xl overflow-hidden shadow-quantum mb-10">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMzYjA3NjQiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDM0aDR2MWgtNHYtMXptMC0xNGg0djFoLTR2LTF6bTAtN2g0djJoLTR2LTJ6bTAgN2g0djVoLTV2LTVoMXptLTE0IDBoNHYxaC00di0xek0xMCAzNGg0djFoLTR2LTF6bTAtMTRoNHYxaC00di0xem0wLTdoNHYyaC00di0yek01MCAzNGg0djFoLTR2LTF6bTAtMTRoNHYxaC00di0xem0wLTdoNHYyaC00di0yeiIvPjwvZz48ZyBmaWxsPSIjMGRlMDllIiBmaWxsLW9wYWNpdHk9IjAuMDUiPjxwYXRoIGQ9Ik0yIDM0aDEwVjI0SDJ2MTB6bTEtOWg4djhoLTh2LTh6bTIwIDE4aDEwVjQzSDIzdjEwem0xLTloOHY4aC04di04em0yMCAwaDEwVjM0SDQ0djEwem0xLTloOHY4aC04di04em0tMjAtMjBoMTBWNEgyNHYxMHptMS05aDh2OGgtOHYtOHoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-50"></div>
            
            {/* Animated elements simulating quantum state visualization */}
            <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
            <div className="absolute top-1/3 left-1/2 w-3 h-3 bg-emerald-400 rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
            <div className="absolute top-1/2 left-1/3 w-2 h-2 bg-purple-400 rounded-full animate-pulse" style={{animationDelay: '0.7s'}}></div>
            <div className="absolute top-2/3 left-2/3 w-3 h-3 bg-emerald-400 rounded-full animate-pulse" style={{animationDelay: '1.1s'}}></div>
            
            {/* Quantum circuit lines */}
            <div className="absolute top-1/4 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-400/50 to-transparent"></div>
            <div className="absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent"></div>
            <div className="absolute top-3/4 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-400/50 to-transparent"></div>
            
            <div className="absolute bottom-4 right-4 text-xs text-foreground/50 font-mono">Quantum Circuit Simulation</div>
          </div>
          
          <div className="text-sm text-foreground/60">
            Premium access only. No free tier available.
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
