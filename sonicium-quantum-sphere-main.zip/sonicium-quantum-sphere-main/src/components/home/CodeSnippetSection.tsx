
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const CodeSnippetSection = () => {
  const qiskitCode = `# Sonicium Q Platform - Quantum Teleportation Example
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, execute
from qiskit.visualization import plot_histogram

# Create quantum registers
q = QuantumRegister(3, name='q')
c = ClassicalRegister(3, name='c')

# Quantum circuit for teleportation
qc = QuantumCircuit(q, c)

# Create entanglement between q[1] and q[2]
qc.h(q[1])
qc.cx(q[1], q[2])

# Create the state to teleport
qc.h(q[0])
qc.t(q[0])

# Bell measurement
qc.cx(q[0], q[1])
qc.h(q[0])
qc.measure(q[0], c[0])
qc.measure(q[1], c[1])

# Apply corrections
qc.z(q[2]).c_if(c[0], 1)
qc.x(q[2]).c_if(c[1], 1)

# Measure the output
qc.measure(q[2], c[2])

# Execute and get results
job = execute(qc, backend=SoniciumQ.get_backend('simulator'), shots=1024)
result = job.result()
counts = result.get_counts(qc)
plot_histogram(counts)`;

  return (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Run Real Quantum Algorithms</h2>
            <p className="text-lg text-foreground/70 max-w-3xl mx-auto">
              Access IBM Quantum hardware directly through our Qiskit integration. Write, test, and deploy quantum algorithms with ease.
            </p>
          </div>
          
          <div className="bg-card/80 backdrop-blur-sm rounded-xl overflow-hidden shadow-lg border border-border">
            <div className="flex items-center bg-muted/80 px-4 py-2 border-b border-border">
              <div className="flex space-x-2 mr-4">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <div className="text-sm text-foreground/70">quantum_teleportation.py</div>
            </div>
            
            <pre className="qiskit-code">{qiskitCode}</pre>
            
            <div className="bg-muted/30 p-4 border-t border-border">
              <div className="flex justify-between items-center">
                <div className="text-sm text-foreground/70">
                  <span className="font-semibold">Result:</span> Quantum teleportation successfully simulated
                </div>
                <Button asChild size="sm">
                  <Link to="/signup">Try Sonicium Q</Link>
                </Button>
              </div>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <p className="text-foreground/70 mb-6">
              Build and run your quantum algorithms with dedicated resources and professional support.
              No free tier available - professional access only.
            </p>
            <Button asChild size="lg">
              <Link to="/signup">Get Started</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CodeSnippetSection;
