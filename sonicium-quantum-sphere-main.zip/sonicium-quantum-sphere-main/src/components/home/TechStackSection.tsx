
const TechStackSection = () => {
  const techStack = [
    {
      name: "Qiskit",
      logo: "https://qiskit.org/documentation/stable/0.19/_static/logo.png",
      description: "Quantum computing SDK"
    },
    {
      name: "Node.js",
      logo: "https://nodejs.org/static/images/logo.svg",
      description: "Backend runtime"
    },
    {
      name: "MongoDB",
      logo: "https://webassets.mongodb.com/_com_assets/cms/mongodb_logo1-76twgcu2dm.png",
      description: "Database solution"
    },
    {
      name: "React",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/1200px-React-icon.svg.png",
      description: "Frontend framework"
    },
    {
      name: "Express",
      logo: "https://expressjs.com/images/express-facebook-share.png",
      description: "Backend framework"
    },
    {
      name: "JWT",
      logo: "https://jwt.io/img/pic_logo.svg",
      description: "Authentication"
    },
    {
      name: "Stripe",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/ba/Stripe_Logo%2C_revised_2016.svg/2560px-Stripe_Logo%2C_revised_2016.svg.png",
      description: "Payment processing"
    },
    {
      name: "Vercel",
      logo: "https://assets.vercel.com/image/upload/front/favicon/vercel/180x180.png",
      description: "Deployment platform"
    }
  ];

  return (
    <section id="tech" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Technology Stack</h2>
          <p className="text-lg text-foreground/70 max-w-3xl mx-auto">
            Built with cutting-edge technologies to provide a robust, secure, and scalable quantum computing platform.
          </p>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {techStack.map((tech, index) => (
            <div key={index} className="flex flex-col items-center p-6 border border-border rounded-lg bg-card/50 hover:shadow-sm transition-shadow">
              <div className="h-12 mb-4 flex items-center justify-center">
                <div className="w-12 h-12 bg-background rounded-md flex items-center justify-center p-2 shadow-sm">
                  {/* This would typically be an image but we're using text placeholders for this example */}
                  <div className="text-lg font-bold text-primary">{tech.name.charAt(0)}</div>
                </div>
              </div>
              <h3 className="text-lg font-medium mb-1">{tech.name}</h3>
              <p className="text-sm text-foreground/60 text-center">{tech.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TechStackSection;
