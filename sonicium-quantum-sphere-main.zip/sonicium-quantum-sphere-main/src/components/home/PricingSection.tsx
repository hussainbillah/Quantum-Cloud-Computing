
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Check } from "lucide-react";

const PricingSection = () => {
  const [isAnnual, setIsAnnual] = useState(true);
  
  const plans = [
    {
      name: "Professional",
      description: "For individual researchers and developers",
      priceMonthly: 149,
      priceAnnual: 1490,
      features: [
        "Access to quantum computers",
        "5 concurrent quantum jobs",
        "50 project storage limit",
        "Basic priority in queue",
        "Email support",
        "API access"
      ],
      cta: "Start Professional",
      popular: false
    },
    {
      name: "Enterprise",
      description: "For teams and organizations",
      priceMonthly: 499,
      priceAnnual: 4990,
      features: [
        "Access to all quantum processors",
        "25 concurrent quantum jobs",
        "Unlimited project storage",
        "High priority in queue",
        "24/7 priority support",
        "Advanced API access",
        "Team collaboration tools",
        "Custom integration options"
      ],
      cta: "Start Enterprise",
      popular: true
    },
    {
      name: "Research",
      description: "For academic institutions",
      priceMonthly: 299,
      priceAnnual: 2990,
      features: [
        "Access to all quantum processors",
        "15 concurrent quantum jobs",
        "500 project storage limit",
        "Medium priority in queue",
        "Business hours support",
        "API access",
        "Academic publication rights",
        "Educational resources"
      ],
      cta: "Start Research",
      popular: false
    }
  ];

  const calculateSavings = (monthly: number, annual: number) => {
    return Math.round(100 - ((annual / 12) * 100 / monthly));
  };
  
  return (
    <section id="pricing" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Subscription Plans</h2>
          <p className="text-lg text-foreground/70 max-w-3xl mx-auto">
            Choose the plan that best fits your quantum computing requirements.
            All plans provide full access to our premium Sonicium Q platform.
          </p>
          
          <div className="flex justify-center mt-8">
            <div className="bg-muted/80 p-1 rounded-full">
              <Button
                variant={isAnnual ? "default" : "ghost"}
                className={`rounded-full ${isAnnual ? '' : 'hover:bg-transparent'}`}
                onClick={() => setIsAnnual(true)}
              >
                Annual 
                <span className="ml-2 text-xs px-2 py-0.5 bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-full">
                  Save up to 20%
                </span>
              </Button>
              <Button
                variant={!isAnnual ? "default" : "ghost"}
                className={`rounded-full ${!isAnnual ? '' : 'hover:bg-transparent'}`}
                onClick={() => setIsAnnual(false)}
              >
                Monthly
              </Button>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => {
            const price = isAnnual ? plan.priceAnnual : plan.priceMonthly;
            const term = isAnnual ? "/year" : "/month";
            const savings = isAnnual ? calculateSavings(plan.priceMonthly, plan.priceAnnual) : 0;
            
            return (
              <div 
                key={index} 
                className={`rounded-2xl overflow-hidden transition-all ${
                  plan.popular 
                    ? 'gradient-border scale-105 shadow-quantum' 
                    : 'border border-border'
                }`}
              >
                <div className={`p-8 bg-card h-full flex flex-col`}>
                  {plan.popular && (
                    <div className="text-xs uppercase font-semibold text-purple-500 mb-3 tracking-wider">
                      Most Popular
                    </div>
                  )}
                  
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <p className="text-foreground/70 mb-6">{plan.description}</p>
                  
                  <div className="mb-6">
                    <span className="text-4xl font-bold">${price}</span>
                    <span className="text-foreground/70 ml-1">{term}</span>
                    
                    {isAnnual && (
                      <div className="text-sm text-emerald-600 dark:text-emerald-400 mt-2">
                        Save {savings}% with annual billing
                      </div>
                    )}
                  </div>
                  
                  <ul className="space-y-3 mb-8 flex-grow">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <Check className="h-5 w-5 text-emerald-500 mr-3 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button asChild className="w-full" variant={plan.popular ? "default" : "outline"}>
                    <Link to="/signup">{plan.cta}</Link>
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="text-center text-foreground/70 mt-12 text-sm max-w-2xl mx-auto">
          All plans require payment upfront. For custom enterprise needs or volume discounts, 
          please contact our sales team for a tailored solution.
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
