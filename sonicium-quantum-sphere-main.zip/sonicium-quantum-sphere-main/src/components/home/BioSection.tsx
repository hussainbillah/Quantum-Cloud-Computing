
import { Facebook, Linkedin, Twitter, Github } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";

const BioSection = () => {
  const socialLinks = [
    { icon: <Facebook className="h-5 w-5" />, href: "#", label: "Facebook", color: "hover:bg-blue-500" },
    { icon: <Twitter className="h-5 w-5" />, href: "#", label: "Twitter (X)", color: "hover:bg-sky-500" },
    { icon: <Linkedin className="h-5 w-5" />, href: "#", label: "LinkedIn", color: "hover:bg-blue-700" },
    { icon: <Github className="h-5 w-5" />, href: "#", label: "GitHub", color: "hover:bg-purple-800" },
  ];

  return (
    <section id="about" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold gradient-text">Meet the Developer</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-emerald-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="overflow-hidden quantum-card">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row items-center gap-8">
                {/* Avatar with glow effect */}
                <div className="relative">
                  <div className="w-48 h-48 rounded-full overflow-hidden border-4 border-purple-200 dark:border-purple-900 shadow-quantum glow-effect">
                    <Avatar className="w-full h-full">
                      <AvatarImage src="https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=400&h=400&fit=crop&crop=faces" alt="Hussain Billah" />
                      <AvatarFallback className="text-2xl bg-gradient-to-br from-purple-700 to-emerald-700 text-white">
                        HB
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-white p-2 rounded-full shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  </div>
                </div>
                
                {/* Bio content */}
                <div className="flex-1 text-center md:text-left">
                  <h2 className="text-3xl font-bold mb-2">Hussain Billah</h2>
                  <h3 className="text-lg text-primary mb-6">Founder & CEO of Sonicium Ltd.</h3>
                  
                  <p className="text-foreground/80 mb-8">
                    Hussain Billah is a visionary entrepreneur and freelancing mentor, 
                    leading Sonicium Ltd. to revolutionize digital infrastructure with 
                    quantum computing solutions.
                  </p>
                  
                  {/* Social links with hover effects */}
                  <div className="flex justify-center md:justify-start space-x-4">
                    {socialLinks.map((social, index) => (
                      <HoverCard key={index}>
                        <HoverCardTrigger asChild>
                          <a 
                            href={social.href} 
                            className={`w-10 h-10 flex items-center justify-center rounded-full bg-background 
                                      border border-border ${social.color} hover:text-primary-foreground 
                                      transition-all duration-300 transform hover:scale-110`}
                            aria-label={social.label}
                          >
                            {social.icon}
                          </a>
                        </HoverCardTrigger>
                        <HoverCardContent className="w-auto py-1.5 px-3">
                          <p className="text-sm">{social.label}</p>
                        </HoverCardContent>
                      </HoverCard>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default BioSection;
