
import { Code, Shield, Zap, Server, Cloud, Lock } from "lucide-react";

const FeaturesSection = () => {
  const features = [
    {
      icon: <Code className="h-8 w-8 text-purple-500" />,
      title: "IBM Quantum API Integration",
      description: "Seamlessly connect with IBM's powerful quantum processors via Qiskit, with no setup required."
    },
    {
      icon: <Shield className="h-8 w-8 text-emerald-500" />,
      title: "Enterprise-Grade Security",
      description: "Your quantum code and data are encrypted and securely stored. Project isolation ensures complete privacy."
    },
    {
      icon: <Zap className="h-8 w-8 text-purple-500" />,
      title: "High-Performance Execution",
      description: "Run your quantum algorithms with the highest priority queue access and dedicated compute resources."
    },
    {
      icon: <Server className="h-8 w-8 text-emerald-500" />,
      title: "Project Management",
      description: "Organize, store, and version your quantum computing projects with our intuitive dashboard interface."
    },
    {
      icon: <Cloud className="h-8 w-8 text-purple-500" />,
      title: "Cloud-Based Development",
      description: "Develop your quantum algorithms from anywhere without local Qiskit installations or complex setups."
    },
    {
      icon: <Lock className="h-8 w-8 text-emerald-500" />,
      title: "Secure Authentication",
      description: "JWT-based authentication system ensures your account and projects remain safe and accessible only to you."
    }
  ];
  
  return (
    <section id="features" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Premium Quantum Features</h2>
          <p className="text-lg text-foreground/70 max-w-3xl mx-auto">
            Sonicium Q provides exclusive access to quantum computing resources with professional tools designed for researchers, developers and enterprises.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="quantum-card p-6 hover:translate-y-[-5px]"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-foreground/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
