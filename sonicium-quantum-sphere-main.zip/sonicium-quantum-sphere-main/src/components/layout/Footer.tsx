
import { Link } from "react-router-dom";
import { Facebook, Linkedin, Twitter, Github } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  const footerLinks = [
    {
      title: "Platform",
      links: [
        { name: "Features", href: "/#features" },
        { name: "Pricing", href: "/#pricing" },
        { name: "Security", href: "/security" },
        { name: "Quantum API", href: "/api" }
      ]
    },
    {
      title: "Resources",
      links: [
        { name: "Documentation", href: "/docs" },
        { name: "API Reference", href: "/api-reference" },
        { name: "Tutorials", href: "/tutorials" },
        { name: "Blog", href: "/blog" }
      ]
    },
    {
      title: "Company",
      links: [
        { name: "About", href: "/#about" },
        { name: "Contact", href: "/contact" },
        { name: "Careers", href: "/careers" }
      ]
    },
    {
      title: "Legal",
      links: [
        { name: "Terms of Service", href: "/terms" },
        { name: "Privacy Policy", href: "/privacy" },
        { name: "Cookie Policy", href: "/cookies" }
      ]
    }
  ];
  
  const socialLinks = [
    { icon: <Facebook className="h-5 w-5" />, href: "#", label: "Facebook" },
    { icon: <Linkedin className="h-5 w-5" />, href: "#", label: "LinkedIn" },
    { icon: <Twitter className="h-5 w-5" />, href: "#", label: "Twitter (X)" },
    { icon: <Github className="h-5 w-5" />, href: "#", label: "GitHub" }
  ];

  return (
    <footer className="pt-20 pb-10 border-t border-border">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand and description */}
          <div className="lg:col-span-2">
            <Link to="/" className="inline-block mb-6">
              <span className="text-2xl font-bold gradient-text">Sonicium Q</span>
            </Link>
            <p className="text-foreground/70 mb-6 max-w-md">
              The premium platform for quantum computing resources. Run real quantum algorithms 
              securely with our enterprise-grade Quantum-as-a-Service platform.
            </p>
            
            {/* Social links */}
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a 
                  key={index} 
                  href={social.href} 
                  className="w-10 h-10 flex items-center justify-center rounded-full bg-muted/50 
                          border border-border hover:bg-primary hover:text-primary-foreground 
                          transition-colors duration-200"
                  aria-label={social.label}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>
          
          {/* Quick links */}
          {footerLinks.map((category, index) => (
            <div key={index}>
              <h3 className="font-semibold text-lg mb-4">{category.title}</h3>
              <ul className="space-y-3">
                {category.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <Link 
                      to={link.href} 
                      className="text-foreground/70 hover:text-primary transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        
        <div className="mt-16 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center">
          <div className="text-foreground/60 text-sm mb-4 md:mb-0">
            &copy; {currentYear} Sonicium Ltd. All rights reserved.
          </div>
          <div className="flex items-center space-x-4 text-sm text-foreground/60">
            <Link to="/terms" className="hover:text-primary">Terms</Link>
            <Link to="/privacy" className="hover:text-primary">Privacy</Link>
            <Link to="/cookies" className="hover:text-primary">Cookies</Link>
            <span>Made in Bangladesh</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
