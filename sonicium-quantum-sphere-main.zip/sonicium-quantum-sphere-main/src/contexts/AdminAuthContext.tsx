
import { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";

type AdminAuthContextType = {
  isAdminAuthenticated: boolean;
  adminLoading: boolean;
  adminLogin: (email: string, password: string) => Promise<void>;
  adminLogout: () => Promise<void>;
  currentAdmin: any | null;
};

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined);

export function AdminAuthProvider({ children }: { children: React.ReactNode }) {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminLoading, setAdminLoading] = useState(true);
  const [currentAdmin, setCurrentAdmin] = useState<any | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    async function checkAdmin() {
      try {
        // Check if user is authenticated
        const { data: sessionData } = await supabase.auth.getSession();
        const session = sessionData.session;

        if (!session) {
          setIsAdminAuthenticated(false);
          setAdminLoading(false);
          return;
        }

        // Check if authenticated user is an admin
        const { data: adminData, error: adminError } = await supabase
          .from('admin_users')
          .select('*')
          .eq('user_id', session.user.id)
          .single();

        if (adminError || !adminData) {
          setIsAdminAuthenticated(false);
          setAdminLoading(false);
          return;
        }

        setCurrentAdmin({
          ...session.user,
          role: adminData.role
        });
        setIsAdminAuthenticated(true);
      } catch (error) {
        console.error('Error checking admin status:', error);
        setIsAdminAuthenticated(false);
      } finally {
        setAdminLoading(false);
      }
    }

    // Set up listener for auth state changes
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN') {
        if (session) {
          checkAdmin();
        }
      } else if (event === 'SIGNED_OUT') {
        setIsAdminAuthenticated(false);
        setCurrentAdmin(null);
      }
    });

    // Initial check
    checkAdmin();

    return () => {
      authListener.subscription?.unsubscribe();
    };
  }, [navigate]);

  async function adminLogin(email: string, password: string) {
    try {
      setAdminLoading(true);
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast({
          variant: "destructive",
          title: "Login failed",
          description: error.message,
        });
        return;
      }

      if (data.user) {
        // Check if user is admin
        const { data: adminData, error: adminError } = await supabase
          .from('admin_users')
          .select('*')
          .eq('user_id', data.user.id)
          .single();

        if (adminError || !adminData) {
          await supabase.auth.signOut();
          toast({
            variant: "destructive",
            title: "Access denied",
            description: "You don't have administrator privileges.",
          });
          return;
        }

        setCurrentAdmin({
          ...data.user,
          role: adminData.role
        });
        setIsAdminAuthenticated(true);
        toast({
          title: "Login successful",
          description: "Welcome back to the admin dashboard!",
        });
        navigate("/admin");
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Login error",
        description: error.message || "An error occurred during login",
      });
    } finally {
      setAdminLoading(false);
    }
  }

  async function adminLogout() {
    try {
      setAdminLoading(true);
      await supabase.auth.signOut();
      setIsAdminAuthenticated(false);
      setCurrentAdmin(null);
      toast({
        title: "Logged out",
        description: "You have been logged out successfully.",
      });
      navigate("/admin/login");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Logout error",
        description: error.message || "An error occurred during logout",
      });
    } finally {
      setAdminLoading(false);
    }
  }

  return (
    <AdminAuthContext.Provider value={{
      isAdminAuthenticated,
      adminLoading,
      adminLogin,
      adminLogout,
      currentAdmin
    }}>
      {children}
    </AdminAuthContext.Provider>
  );
}

export function useAdminAuth() {
  const context = useContext(AdminAuthContext);
  if (context === undefined) {
    throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  }
  return context;
}
